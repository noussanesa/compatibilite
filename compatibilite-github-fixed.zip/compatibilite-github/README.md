# Compatibilité — dossier prêt pour GitHub

Contenu :

- `index.html` : site complet
- `templates/questionnaire-modele.json` : bibliothèque publique de 183 questions

## Mise à jour GitHub

1. Remplace l’ancien `index.html` par celui-ci.
2. Crée un dossier `templates` à la racine du dépôt.
3. Ajoute `questionnaire-modele.json` dans `templates/`.
4. Commit les changements.
5. Vercel redéploiera automatiquement si le dépôt est connecté. Sinon relance `npx vercel --prod`.

## Confidentialité

Le fichier modèle public ne contient **aucun score, coefficient ni alerte** du questionnaire personnel d’Inès. Le fichier privé `questionnaire_compatibilite_master.json` ne doit pas être ajouté au dépôt public.
